import Header from "./components/Header"

function App() {
  return (
    <>
      <Header />

      {/* Hero Section */}
      <section className="hero-section" id="home">
        <div className="hero-bg" />
        <div className="hero-shapes">
          <div className="floating-accent accent-1" />
          <div className="floating-accent accent-2" />
          <div className="floating-accent accent-3" />
        </div>
        <div className="hero-content reveal">
          <h1 className="hero-title">Capturing Moments</h1>
          <p className="hero-subtitle">Professional Photography Portfolio</p>
          <a href="#portfolio" className="cta-button">
            View My Work
          </a>
        </div>
      </section>
      {/* Portfolio Section with Coverflow */}
      <section className="portfolio-section" id="portfolio">
        <div className="section-header reveal">
          <h2 className="section-title">Featured Work</h2>
          <p className="section-subtitle">
            Explore my latest photography projects across various genres and styles
          </p>
        </div>
        <div className="coverflow-wrapper">
          <div className="coverflow-container" id="coverflowContainer">
            {/* Portrait Photography */}
            <div className="coverflow-item" data-index={0}>
              <img
                src="public/images/templatemo-amber-folio-01.jpg"
                alt="Portrait Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Portrait</div>
                <h3 className="portfolio-title">Human Stories</h3>
                <p className="portfolio-description">
                  Capturing authentic emotions and personalities
                </p>
              </div>
            </div>
            {/* Landscape Photography */}
            <div className="coverflow-item" data-index={1}>
              <img
                src="public/images/templatemo-amber-folio-02.jpg"
                alt="Landscape Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Landscape</div>
                <h3 className="portfolio-title">Nature's Canvas</h3>
                <p className="portfolio-description">
                  Breathtaking vistas and natural wonders
                </p>
              </div>
            </div>
            {/* Street Photography */}
            <div className="coverflow-item" data-index={2}>
              <img
                src="public/images/templatemo-amber-folio-03.jpg"
                alt="Street Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Street</div>
                <h3 className="portfolio-title">Urban Life</h3>
                <p className="portfolio-description">
                  Candid moments in city environments
                </p>
              </div>
            </div>
            {/* Architecture Photography */}
            <div className="coverflow-item" data-index={3}>
              <img
                src="public/images/templatemo-amber-folio-04.jpg"
                alt="Architecture Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Architecture</div>
                <h3 className="portfolio-title">Structural Beauty</h3>
                <p className="portfolio-description">
                  Modern lines and timeless designs
                </p>
              </div>
            </div>
            {/* Fashion Photography */}
            <div className="coverflow-item" data-index={4}>
              <img
                src="public/images/templatemo-amber-folio-05.jpg"
                alt="Fashion Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Fashion</div>
                <h3 className="portfolio-title">Style &amp; Elegance</h3>
                <p className="portfolio-description">
                  High fashion and editorial shoots
                </p>
              </div>
            </div>
            {/* Wildlife Photography */}
            <div className="coverflow-item" data-index={5}>
              <img
                src="public/images/templatemo-amber-folio-06.jpg"
                alt="Wildlife Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Wildlife</div>
                <h3 className="portfolio-title">Wild Kingdom</h3>
                <p className="portfolio-description">
                  Nature's magnificent creatures
                </p>
              </div>
            </div>
            {/* Black & White Photography */}
            <div className="coverflow-item" data-index={6}>
              <img
                src="public/images/templatemo-amber-folio-07.jpg"
                alt="Black and White Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Monochrome</div>
                <h3 className="portfolio-title">Timeless Classics</h3>
                <p className="portfolio-description">The art of black and white</p>
              </div>
            </div>
            {/* Event Photography */}
            <div className="coverflow-item" data-index={7}>
              <img
                src="public/images/templatemo-amber-folio-08.jpg"
                alt="Event Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Events</div>
                <h3 className="portfolio-title">Special Moments</h3>
                <p className="portfolio-description">Weddings and celebrations</p>
              </div>
            </div>
            {/* Abstract Photography */}
            <div className="coverflow-item" data-index={8}>
              <img
                src="public/images/templatemo-amber-folio-09.jpg"
                alt="Abstract Photography"
                className="portfolio-image"
              />
              <div className="portfolio-overlay">
                <div className="portfolio-category">Abstract</div>
                <h3 className="portfolio-title">Creative Vision</h3>
                <p className="portfolio-description">
                  Artistic and experimental works
                </p>
              </div>
            </div>
          </div>
          {/* Navigation Controls */}
          <div className="coverflow-controls">
            <button className="control-btn" id="prevBtn">
              ‹
            </button>
            <button className="control-btn" id="playPauseBtn">
              ▶
            </button>
            <button className="control-btn" id="nextBtn">
              ›
            </button>
          </div>
          {/* Indicators */}
          <div className="indicators" id="indicators">
            <div className="indicator active" data-index={0} />
            <div className="indicator" data-index={1} />
            <div className="indicator" data-index={2} />
            <div className="indicator" data-index={3} />
            <div className="indicator" data-index={4} />
            <div className="indicator" data-index={5} />
            <div className="indicator" data-index={6} />
            <div className="indicator" data-index={7} />
            <div className="indicator" data-index={8} />
          </div>
        </div>
      </section>
      {/* About Section */}
      <section className="about-section" id="about">
        <div className="about-container reveal">
          <div className="about-image">
            <img src="public/images/templatemo-about-artist.jpg" alt="Photographer" />
          </div>
          <div className="about-content">
            <h2>About the Artist</h2>
            <p>
              With over a decade of experience in professional photography, I
              specialize in capturing the extraordinary in everyday moments. My
              journey began with a simple camera and an insatiable curiosity about
              the world around me.
            </p>
            <p>
              From the bustling streets of urban landscapes to the serene beauty of
              nature, I strive to tell stories through my lens. Each photograph is a
              carefully crafted piece of art, designed to evoke emotion and preserve
              memories that last a lifetime.
            </p>
            <p>
              My work has been featured in numerous galleries and publications
              worldwide, but my greatest satisfaction comes from creating images
              that resonate with people on a personal level.
            </p>
            <div className="stats">
              <div className="stat-item">
                <div className="stat-number">500+</div>
                <div className="stat-label">Projects</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">10+</div>
                <div className="stat-label">Years</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">50+</div>
                <div className="stat-label">Awards</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Services Section */}
      <section className="services-section" id="services">
        <div className="services-container">
          <div className="section-header reveal">
            <h2 className="section-title">Services Offered</h2>
            <p className="section-subtitle">
              Professional photography services tailored to capture your vision
            </p>
          </div>
          <div className="services-grid reveal">
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C10.34 2 9 3.34 9 5C9 6.66 10.34 8 12 8C13.66 8 15 6.66 15 5C15 3.34 13.66 2 12 2ZM12 9C8.69 9 6 11.69 6 15C6 16.66 6.56 18.17 7.5 19.32V22L12 20L16.5 22V19.32C17.44 18.17 18 16.66 18 15C18 11.69 15.31 9 12 9Z" />
                </svg>
              </div>
              <h3 className="service-title">Portrait Sessions</h3>
              <p className="service-description">
                Professional headshots, personal branding, and lifestyle portraits.
                Each session includes consultation, styling guidance, and expert
                retouching.
              </p>
              <div className="service-price">Starting at $450</div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 6.5C12 5.67 11.33 5 10.5 5S9 5.67 9 6.5 9.67 8 10.5 8 12 7.33 12 6.5M13.5 5C12.67 5 12 5.67 12 6.5S12.67 8 13.5 8 15 7.33 15 6.5 14.33 5 13.5 5M12 21.35L5.35 14.7C3.58 12.93 2.61 10.54 2.61 8.04C2.61 3.74 6.05 0.25 10.36 0.21C14.72 0.17 18.29 3.69 18.29 8C18.29 10.53 17.34 12.88 15.58 14.65L12 21.35Z" />
                </svg>
              </div>
              <h3 className="service-title">Wedding Photography</h3>
              <p className="service-description">
                Complete wedding day coverage from preparation to reception.
                Includes engagement session, two photographers, and premium album
                design.
              </p>
              <div className="service-price">Starting at $2,800</div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 3H14.82C14.4 1.84 13.3 1 12 1S9.6 1.84 9.18 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM12 3C12.55 3 13 3.45 13 4S12.55 5 12 5 11 4.55 11 4 11.45 3 12 3ZM12 18L8 14H11V9H13V14H16L12 18Z" />
                </svg>
              </div>
              <h3 className="service-title">Commercial Work</h3>
              <p className="service-description">
                Product photography, corporate events, architectural shoots, and
                marketing campaigns. High-resolution images with commercial
                licensing.
              </p>
              <div className="service-price">Custom Pricing</div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20.5 11H19V7C19 5.9 18.1 5 17 5H13V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4C2.9 5 2 5.9 2 7V10.8H3.5C4.99 10.8 6.2 12.01 6.2 13.5S4.99 16.2 3.5 16.2H2V20C2 21.1 2.9 22 4 22H7.8V20.5C7.8 19.01 9.01 17.8 10.5 17.8S13.2 19.01 13.2 20.5V22H17C18.1 22 19 21.1 19 20V16H20.5C21.88 16 23 14.88 23 13.5S21.88 11 20.5 11Z" />
                </svg>
              </div>
              <h3 className="service-title">Fine Art Prints</h3>
              <p className="service-description">
                Museum-quality giclée prints on archival paper. Limited editions
                with certificates of authenticity. Custom framing available.
              </p>
              <div className="service-price">Starting at $180</div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2L2 7V9C2 14.55 5.84 19.74 11 21C16.16 19.74 20 14.55 20 9V7L12 2ZM12 11.5L9 8.5L10.41 7.09L12 8.67L15.59 5.09L17 6.5L12 11.5Z" />
                </svg>
              </div>
              <h3 className="service-title">Photo Editing</h3>
              <p className="service-description">
                Professional retouching, color grading, and composite creation. Fast
                turnaround with unlimited revisions until perfect.
              </p>
              <div className="service-price">$50 per hour</div>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C6.48 2 2 6.48 2 12S6.48 22 12 22 22 17.52 22 12 17.52 2 12 2ZM11 17L6 12L7.41 10.59L11 14.17L16.59 8.59L18 10L11 17Z" />
                </svg>
              </div>
              <h3 className="service-title">Photography Workshops</h3>
              <p className="service-description">
                One-on-one mentoring sessions, group workshops, and online
                masterclasses. Learn composition, lighting, and post-processing
                techniques.
              </p>
              <div className="service-price">Starting at $200</div>
            </div>
          </div>
        </div>
      </section>
      {/* Contact Section */}
      <section className="contact-section" id="contact">
        <div className="contact-container">
          <div className="section-header reveal">
            <h2 className="section-title">Get In Touch</h2>
            <p className="section-subtitle">
              Let's create something beautiful together
            </p>
          </div>
          <div className="contact-info reveal">
            <a href="mailto:hello@capture.com" className="contact-item">
              <div className="contact-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4ZM20 8L12 13L4 8V6L12 11L20 6V8Z" />
                </svg>
              </div>
              <div className="contact-label">Email</div>
              <div className="contact-value">hello@capture.com</div>
            </a>
            <a href="tel:+1234567890" className="contact-item">
              <div className="contact-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6.62 10.79C8.06 13.62 10.38 15.94 13.21 17.38L15.41 15.18C15.69 14.9 16.08 14.82 16.43 14.93C17.55 15.3 18.75 15.5 20 15.5C20.55 15.5 21 15.95 21 16.5V20C21 20.55 20.55 21 20 21C10.61 21 3 13.39 3 4C3 3.45 3.45 3 4 3H7.5C8.05 3 8.5 3.45 8.5 4C8.5 5.25 8.7 6.45 9.07 7.57C9.18 7.92 9.1 8.31 8.82 8.59L6.62 10.79Z" />
                </svg>
              </div>
              <div className="contact-label">Phone</div>
              <div className="contact-value">+1 (234) 567-890</div>
            </a>
            <a
              href="https://maps.google.com/?q=New+York+USA"
              target="_blank"
              rel="noopener"
              className="contact-item"
            >
              <div className="contact-icon">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22S19 14.25 19 9C19 5.13 15.87 2 12 2ZM12 11.5C10.62 11.5 9.5 10.38 9.5 9S10.62 6.5 12 6.5S14.5 7.62 14.5 9S13.38 11.5 12 11.5Z" />
                </svg>
              </div>
              <div className="contact-label">Studio</div>
              <div className="contact-value">New York, USA</div>
            </a>
          </div>
        </div>
      </section>
      {/* Footer */}
      <footer>
        <div className="footer-content">
          <div className="social-links">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener"
              className="social-link"
              aria-label="Instagram"
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.8 2H16.2C19.4 2 22 4.6 22 7.8V16.2C22 19.4 19.4 22 16.2 22H7.8C4.6 22 2 19.4 2 16.2V7.8C2 4.6 4.6 2 7.8 2M7.6 4C5.61 4 4 5.61 4 7.6V16.4C4 18.39 5.61 20 7.6 20H16.4C18.39 20 20 18.39 20 16.4V7.6C20 5.61 18.39 4 16.4 4H7.6M17.25 5.5C17.94 5.5 18.5 6.06 18.5 6.75S17.94 8 17.25 8S16 7.44 16 6.75S16.56 5.5 17.25 5.5M12 7C14.76 7 17 9.24 17 12S14.76 17 12 17S7 14.76 7 12S9.24 7 12 7M12 9C10.34 9 9 10.34 9 12S10.34 15 12 15S15 13.66 15 12S13.66 9 12 9Z" />
              </svg>
            </a>
            <a
              href="https://facebook.com/templatemo"
              target="_blank"
              rel="noopener"
              className="social-link"
              aria-label="Facebook"
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96C18.34 21.21 22 17.06 22 12.06C22 6.53 17.5 2.04 12 2.04Z" />
              </svg>
            </a>
            <a
              href="https://x.com/minthu"
              target="_blank"
              rel="noopener"
              className="social-link"
              aria-label="Twitter"
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.46 6C21.69 6.35 20.86 6.58 20 6.69C20.88 6.16 21.56 5.32 21.88 4.31C21.05 4.81 20.13 5.16 19.16 5.36C18.37 4.5 17.26 4 16 4C13.65 4 11.73 5.92 11.73 8.29C11.73 8.63 11.77 8.96 11.84 9.27C8.28 9.09 5.11 7.38 3 4.79C2.63 5.42 2.42 6.16 2.42 6.94C2.42 8.43 3.17 9.75 4.33 10.5C3.62 10.5 2.96 10.3 2.38 10V10.03C2.38 12.11 3.86 13.85 5.82 14.24C5.46 14.34 5.08 14.39 4.69 14.39C4.42 14.39 4.15 14.36 3.89 14.31C4.43 16 6 17.26 7.89 17.29C6.43 18.45 4.58 19.13 2.56 19.13C2.22 19.13 1.88 19.11 1.54 19.07C3.44 20.29 5.74 21 8.23 21C16 21 20.33 14.46 20.33 8.79C20.33 8.6 20.33 8.42 20.32 8.23C21.16 7.63 21.88 6.87 22.46 6Z" />
              </svg>
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener"
              className="social-link"
              aria-label="LinkedIn"
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 3C19.55 3 20.05 3.21 20.41 3.59C20.79 3.95 21 4.45 21 5V19C21 19.55 20.79 20.05 20.41 20.41C20.05 20.79 19.55 21 19 21H5C4.45 21 3.95 20.79 3.59 20.41C3.21 20.05 3 19.55 3 19V5C3 4.45 3.21 3.95 3.59 3.59C3.95 3.21 4.45 3 5 3H19M18.5 18.5V13.2C18.5 11.87 17.45 10.82 16.12 10.82C15.21 10.82 14.46 11.37 14.17 12.15V11H11.5V18.5H14.17V13.57C14.17 12.82 14.79 12.2 15.54 12.2C16.29 12.2 16.91 12.82 16.91 13.57V18.5H18.5M6.88 9.57C7.63 9.57 8.25 8.96 8.25 8.21C8.25 7.46 7.63 6.84 6.88 6.84C6.13 6.84 5.5 7.46 5.5 8.21C5.5 8.96 6.13 9.57 6.88 9.57M8.21 18.5V11H5.5V18.5H8.21Z" />
              </svg>
            </a>
          </div>
          <p className="footer-text">
            © 2026 Amber Folio Photography. All rights reserved.
            <br />
            Design:{" "}
            <a href="https://templatemo.com" target="_blank" rel="noopener">
              TemplateMo
            </a>
          </p>
        </div>
      </footer>
    </>
  )
}

export default App
