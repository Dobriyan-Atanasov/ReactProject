export default function Header() {
    return (
        <>
            {/* Loading Screen */}
            <div className="loading-screen" id="loadingScreen">
                <div className="loader" />
            </div>
            {/* Header Navigation */}
            <header id="header">
                <nav>
                    <a href="#home" className="logo">
                        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 20C16.4 20 20 16.4 20 12C20 7.6 16.4 4 12 4C7.6 4 4 7.6 4 12C4 16.4 7.6 20 12 20M12 2C18.5 2 22 6.5 22 12C22 17.5 17.5 22 12 22C6.5 22 2 17.5 2 12C2 6.5 6.5 2 12 2M14.3 16.2L12 10L9.7 16.2L7 11.3L11.3 7L16.2 9.7L14.3 16.2M8.8 17L12 8L15.2 17L20 12L15.2 7L12 15L8.8 7L4 12L8.8 17Z" />
                        </svg>
                        Amber Folio
                    </a>
                    <ul className="nav-menu" id="navMenu">
                        <li>
                            <a href="#home">Home</a>
                        </li>
                        <li>
                            <a href="#portfolio">Portfolio</a>
                        </li>
                        <li>
                            <a href="#about">About</a>
                        </li>
                        <li>
                            <a href="#services">Services</a>
                        </li>
                        <li>
                            <a href="#contact">Contact</a>
                        </li>
                    </ul>
                    <div className="menu-toggle" id="menuToggle">
                        <span />
                        <span />
                        <span />
                    </div>
                </nav>
            </header>
        </>
    );
}